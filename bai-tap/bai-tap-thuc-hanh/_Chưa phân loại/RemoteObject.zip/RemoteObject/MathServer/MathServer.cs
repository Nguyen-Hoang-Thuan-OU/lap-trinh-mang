﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Http;
using RemoteObject;
namespace MathServer
{
    public partial class MathServer : Form
    {
        public MathServer()
        {
            InitializeComponent();
        }

        private void MathServer_Load(object sender, EventArgs e)
        {
            HttpChannel chan = new HttpChannel(9050);
            ChannelServices.RegisterChannel(chan);
            RemotingConfiguration.RegisterWellKnownServiceType(typeof(RemoteObject.MathClass), "MyMathServer", WellKnownObjectMode.SingleCall);
            Console.WriteLine("Nhấn Enter để thoát...");
            Console.ReadLine();
        }
    }
}

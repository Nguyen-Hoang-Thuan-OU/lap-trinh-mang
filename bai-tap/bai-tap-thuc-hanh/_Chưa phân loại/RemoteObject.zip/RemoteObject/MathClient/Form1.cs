﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Http;
using RemoteObject;

namespace MathClient
{
    public partial class MathClient : Form
    {
        public MathClient()
        {
            InitializeComponent();
        }

        private void btnKq_Click(object sender, EventArgs e)
        {
            {
                HttpChannel chan = new HttpChannel();
                ChannelServices.RegisterChannel(chan);
                MathClass obj = (MathClass)Activator.GetObject(
                  typeof(MathClass), "http://127.0.0.1:9050/MyMathServer");
                if (obj == null)
                    System.Console.WriteLine("Could not locate server");
                else
                {
                    int a = Convert.ToInt32(txtA.Text);
                    int b = Convert.ToInt32(txtB.Text);
                    int c = obj.Add(a, b);
                    txtAdd.Text = c.ToString();
                    c = obj.Subtract(a, b);
                    txtSub.Text=c.ToString();
                    c = obj.Multiply(a, b);
                    txtMul.Text=c.ToString();
                    c = obj.Divide(a, b);
                    txtDiv.Text = c.ToString();
                }
            }
        }
    }
}
﻿namespace POPMAIL
{
    partial class SMTP
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtfrom = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.lblstatus = new System.Windows.Forms.Label();
            this.txtbody = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.cmdattach = new System.Windows.Forms.Button();
            this.txtattach = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtsubject = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtcc = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtto = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.cmdexit = new System.Windows.Forms.Button();
            this.cmdsend = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtfrom
            // 
            this.txtfrom.Location = new System.Drawing.Point(94, 34);
            this.txtfrom.Margin = new System.Windows.Forms.Padding(4);
            this.txtfrom.Name = "txtfrom";
            this.txtfrom.Size = new System.Drawing.Size(375, 22);
            this.txtfrom.TabIndex = 31;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(14, 40);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(40, 17);
            this.label6.TabIndex = 30;
            this.label6.Text = "From";
            // 
            // lblstatus
            // 
            this.lblstatus.AutoSize = true;
            this.lblstatus.Location = new System.Drawing.Point(14, 409);
            this.lblstatus.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblstatus.Name = "lblstatus";
            this.lblstatus.Size = new System.Drawing.Size(52, 17);
            this.lblstatus.TabIndex = 29;
            this.lblstatus.Text = "Status:";
            // 
            // txtbody
            // 
            this.txtbody.Location = new System.Drawing.Point(18, 216);
            this.txtbody.Margin = new System.Windows.Forms.Padding(4);
            this.txtbody.Multiline = true;
            this.txtbody.Name = "txtbody";
            this.txtbody.Size = new System.Drawing.Size(451, 187);
            this.txtbody.TabIndex = 28;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(14, 196);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(44, 17);
            this.label5.TabIndex = 27;
            this.label5.Text = "Body:";
            // 
            // cmdattach
            // 
            this.cmdattach.Location = new System.Drawing.Point(414, 161);
            this.cmdattach.Margin = new System.Windows.Forms.Padding(4);
            this.cmdattach.Name = "cmdattach";
            this.cmdattach.Size = new System.Drawing.Size(56, 27);
            this.cmdattach.TabIndex = 26;
            this.cmdattach.Text = "...";
            this.cmdattach.UseVisualStyleBackColor = true;
            // 
            // txtattach
            // 
            this.txtattach.Location = new System.Drawing.Point(94, 162);
            this.txtattach.Margin = new System.Windows.Forms.Padding(4);
            this.txtattach.Name = "txtattach";
            this.txtattach.Size = new System.Drawing.Size(315, 22);
            this.txtattach.TabIndex = 25;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(14, 168);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(52, 17);
            this.label4.TabIndex = 24;
            this.label4.Text = "Attach:";
            // 
            // txtsubject
            // 
            this.txtsubject.Location = new System.Drawing.Point(94, 130);
            this.txtsubject.Margin = new System.Windows.Forms.Padding(4);
            this.txtsubject.Name = "txtsubject";
            this.txtsubject.Size = new System.Drawing.Size(375, 22);
            this.txtsubject.TabIndex = 23;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(14, 136);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(59, 17);
            this.label3.TabIndex = 22;
            this.label3.Text = "Subject:";
            // 
            // txtcc
            // 
            this.txtcc.Location = new System.Drawing.Point(94, 98);
            this.txtcc.Margin = new System.Windows.Forms.Padding(4);
            this.txtcc.Name = "txtcc";
            this.txtcc.Size = new System.Drawing.Size(375, 22);
            this.txtcc.TabIndex = 21;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(14, 104);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(30, 17);
            this.label2.TabIndex = 20;
            this.label2.Text = "CC:";
            // 
            // txtto
            // 
            this.txtto.Location = new System.Drawing.Point(94, 66);
            this.txtto.Margin = new System.Windows.Forms.Padding(4);
            this.txtto.Name = "txtto";
            this.txtto.Size = new System.Drawing.Size(375, 22);
            this.txtto.TabIndex = 19;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(14, 72);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(29, 17);
            this.label1.TabIndex = 18;
            this.label1.Text = "To:";
            // 
            // cmdexit
            // 
            this.cmdexit.Location = new System.Drawing.Point(107, 4);
            this.cmdexit.Margin = new System.Windows.Forms.Padding(4);
            this.cmdexit.Name = "cmdexit";
            this.cmdexit.Size = new System.Drawing.Size(101, 30);
            this.cmdexit.TabIndex = 17;
            this.cmdexit.Text = "Back";
            this.cmdexit.UseVisualStyleBackColor = true;
            // 
            // cmdsend
            // 
            this.cmdsend.Location = new System.Drawing.Point(7, 4);
            this.cmdsend.Margin = new System.Windows.Forms.Padding(4);
            this.cmdsend.Name = "cmdsend";
            this.cmdsend.Size = new System.Drawing.Size(103, 30);
            this.cmdsend.TabIndex = 16;
            this.cmdsend.Text = "Send";
            this.cmdsend.UseVisualStyleBackColor = true;
            // 
            // SMTP
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(476, 430);
            this.Controls.Add(this.txtfrom);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.lblstatus);
            this.Controls.Add(this.txtbody);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.cmdattach);
            this.Controls.Add(this.txtattach);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtsubject);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtcc);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtto);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cmdexit);
            this.Controls.Add(this.cmdsend);
            this.Name = "SMTP";
            this.Text = "SMTP";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtfrom;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lblstatus;
        private System.Windows.Forms.TextBox txtbody;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button cmdattach;
        private System.Windows.Forms.TextBox txtattach;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtsubject;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtcc;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtto;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button cmdexit;
        private System.Windows.Forms.Button cmdsend;
    }
}
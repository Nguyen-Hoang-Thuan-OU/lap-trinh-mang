﻿namespace POPMAIL
{
    partial class POP3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnLogout = new System.Windows.Forms.Button();
            this.lstmail = new System.Windows.Forms.ListView();
            this.lblstatus = new System.Windows.Forms.Label();
            this.txtbody = new System.Windows.Forms.TextBox();
            this.lblsubject = new System.Windows.Forms.Label();
            this.lblto = new System.Windows.Forms.Label();
            this.lblfrom = new System.Windows.Forms.Label();
            this.cmdexit = new System.Windows.Forms.Button();
            this.cdmsendmail = new System.Windows.Forms.Button();
            this.cmdlogin = new System.Windows.Forms.Button();
            this.txtpassword = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtusername = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtserver = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnLogout
            // 
            this.btnLogout.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnLogout.Location = new System.Drawing.Point(611, 45);
            this.btnLogout.Margin = new System.Windows.Forms.Padding(4);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(85, 30);
            this.btnLogout.TabIndex = 33;
            this.btnLogout.Text = "LogOut";
            this.btnLogout.UseVisualStyleBackColor = true;
            // 
            // lstmail
            // 
            this.lstmail.ForeColor = System.Drawing.SystemColors.WindowText;
            this.lstmail.FullRowSelect = true;
            this.lstmail.GridLines = true;
            this.lstmail.Location = new System.Drawing.Point(46, 139);
            this.lstmail.Margin = new System.Windows.Forms.Padding(4);
            this.lstmail.Name = "lstmail";
            this.lstmail.Size = new System.Drawing.Size(649, 131);
            this.lstmail.TabIndex = 32;
            this.lstmail.UseCompatibleStateImageBehavior = false;
            this.lstmail.View = System.Windows.Forms.View.Details;
            // 
            // lblstatus
            // 
            this.lblstatus.AutoSize = true;
            this.lblstatus.Location = new System.Drawing.Point(42, 484);
            this.lblstatus.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblstatus.Name = "lblstatus";
            this.lblstatus.Size = new System.Drawing.Size(52, 17);
            this.lblstatus.TabIndex = 31;
            this.lblstatus.Text = "Status:";
            // 
            // txtbody
            // 
            this.txtbody.Location = new System.Drawing.Point(47, 352);
            this.txtbody.Margin = new System.Windows.Forms.Padding(4);
            this.txtbody.Multiline = true;
            this.txtbody.Name = "txtbody";
            this.txtbody.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtbody.Size = new System.Drawing.Size(648, 115);
            this.txtbody.TabIndex = 30;
            // 
            // lblsubject
            // 
            this.lblsubject.AutoSize = true;
            this.lblsubject.Location = new System.Drawing.Point(43, 332);
            this.lblsubject.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblsubject.Name = "lblsubject";
            this.lblsubject.Size = new System.Drawing.Size(59, 17);
            this.lblsubject.TabIndex = 29;
            this.lblsubject.Text = "Subject:";
            // 
            // lblto
            // 
            this.lblto.AutoSize = true;
            this.lblto.Location = new System.Drawing.Point(43, 303);
            this.lblto.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblto.Name = "lblto";
            this.lblto.Size = new System.Drawing.Size(29, 17);
            this.lblto.TabIndex = 28;
            this.lblto.Text = "To:";
            // 
            // lblfrom
            // 
            this.lblfrom.AutoSize = true;
            this.lblfrom.Location = new System.Drawing.Point(43, 274);
            this.lblfrom.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblfrom.Name = "lblfrom";
            this.lblfrom.Size = new System.Drawing.Size(44, 17);
            this.lblfrom.TabIndex = 27;
            this.lblfrom.Text = "From:";
            // 
            // cmdexit
            // 
            this.cmdexit.Location = new System.Drawing.Point(611, 102);
            this.cmdexit.Margin = new System.Windows.Forms.Padding(4);
            this.cmdexit.Name = "cmdexit";
            this.cmdexit.Size = new System.Drawing.Size(85, 30);
            this.cmdexit.TabIndex = 26;
            this.cmdexit.Text = "Exit";
            this.cmdexit.UseVisualStyleBackColor = true;
            // 
            // cdmsendmail
            // 
            this.cdmsendmail.Location = new System.Drawing.Point(611, 76);
            this.cdmsendmail.Margin = new System.Windows.Forms.Padding(4);
            this.cdmsendmail.Name = "cdmsendmail";
            this.cdmsendmail.Size = new System.Drawing.Size(85, 30);
            this.cdmsendmail.TabIndex = 25;
            this.cdmsendmail.Text = "Compose";
            this.cdmsendmail.UseVisualStyleBackColor = true;
            // 
            // cmdlogin
            // 
            this.cmdlogin.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cmdlogin.Location = new System.Drawing.Point(611, 16);
            this.cmdlogin.Margin = new System.Windows.Forms.Padding(4);
            this.cmdlogin.Name = "cmdlogin";
            this.cmdlogin.Size = new System.Drawing.Size(85, 30);
            this.cmdlogin.TabIndex = 24;
            this.cmdlogin.Text = "Login";
            this.cmdlogin.UseVisualStyleBackColor = true;
            // 
            // txtpassword
            // 
            this.txtpassword.Location = new System.Drawing.Point(180, 81);
            this.txtpassword.Margin = new System.Windows.Forms.Padding(4);
            this.txtpassword.Name = "txtpassword";
            this.txtpassword.PasswordChar = '*';
            this.txtpassword.Size = new System.Drawing.Size(241, 22);
            this.txtpassword.TabIndex = 23;
            this.txtpassword.Text = "123";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(42, 90);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(69, 17);
            this.label3.TabIndex = 22;
            this.label3.Text = "Password";
            // 
            // txtusername
            // 
            this.txtusername.Location = new System.Drawing.Point(180, 49);
            this.txtusername.Margin = new System.Windows.Forms.Padding(4);
            this.txtusername.Name = "txtusername";
            this.txtusername.Size = new System.Drawing.Size(241, 22);
            this.txtusername.TabIndex = 21;
            this.txtusername.Text = "test1@test.com";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(42, 58);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(75, 17);
            this.label2.TabIndex = 20;
            this.label2.Text = "UserName";
            // 
            // txtserver
            // 
            this.txtserver.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtserver.Location = new System.Drawing.Point(180, 17);
            this.txtserver.Margin = new System.Windows.Forms.Padding(4);
            this.txtserver.Name = "txtserver";
            this.txtserver.Size = new System.Drawing.Size(241, 22);
            this.txtserver.TabIndex = 19;
            this.txtserver.Text = "192.168.81.100";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(42, 26);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(50, 17);
            this.label1.TabIndex = 18;
            this.label1.Text = "Server";
            // 
            // POP3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(739, 516);
            this.Controls.Add(this.btnLogout);
            this.Controls.Add(this.lstmail);
            this.Controls.Add(this.lblstatus);
            this.Controls.Add(this.txtbody);
            this.Controls.Add(this.lblsubject);
            this.Controls.Add(this.lblto);
            this.Controls.Add(this.lblfrom);
            this.Controls.Add(this.cmdexit);
            this.Controls.Add(this.cdmsendmail);
            this.Controls.Add(this.cmdlogin);
            this.Controls.Add(this.txtpassword);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtusername);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtserver);
            this.Controls.Add(this.label1);
            this.Name = "POP3";
            this.Text = "PopMail";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnLogout;
        private System.Windows.Forms.ListView lstmail;
        private System.Windows.Forms.Label lblstatus;
        private System.Windows.Forms.TextBox txtbody;
        private System.Windows.Forms.Label lblsubject;
        private System.Windows.Forms.Label lblto;
        private System.Windows.Forms.Label lblfrom;
        private System.Windows.Forms.Button cmdexit;
        private System.Windows.Forms.Button cdmsendmail;
        private System.Windows.Forms.Button cmdlogin;
        private System.Windows.Forms.TextBox txtpassword;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtusername;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtserver;
        private System.Windows.Forms.Label label1;
    }
}


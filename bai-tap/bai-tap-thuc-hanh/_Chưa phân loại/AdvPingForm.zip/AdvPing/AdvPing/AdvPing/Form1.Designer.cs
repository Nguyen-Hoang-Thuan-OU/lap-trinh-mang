﻿namespace AdvPing
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.results = new System.Windows.Forms.ListBox();
            this.closeit = new System.Windows.Forms.Button();
            this.stopit = new System.Windows.Forms.Button();
            this.sendit = new System.Windows.Forms.Button();
            this.databox = new System.Windows.Forms.TextBox();
            this.hostbox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // results
            // 
            this.results.FormattingEnabled = true;
            this.results.Location = new System.Drawing.Point(12, 52);
            this.results.Name = "results";
            this.results.Size = new System.Drawing.Size(445, 316);
            this.results.TabIndex = 16;
            // 
            // closeit
            // 
            this.closeit.Location = new System.Drawing.Point(382, 382);
            this.closeit.Name = "closeit";
            this.closeit.Size = new System.Drawing.Size(75, 23);
            this.closeit.TabIndex = 15;
            this.closeit.Text = "Close";
            this.closeit.UseVisualStyleBackColor = true;
            // 
            // stopit
            // 
            this.stopit.Location = new System.Drawing.Point(382, 23);
            this.stopit.Name = "stopit";
            this.stopit.Size = new System.Drawing.Size(75, 23);
            this.stopit.TabIndex = 14;
            this.stopit.Text = "Stop";
            this.stopit.UseVisualStyleBackColor = true;
            // 
            // sendit
            // 
            this.sendit.Location = new System.Drawing.Point(301, 23);
            this.sendit.Name = "sendit";
            this.sendit.Size = new System.Drawing.Size(75, 23);
            this.sendit.TabIndex = 13;
            this.sendit.Text = "Start";
            this.sendit.UseVisualStyleBackColor = true;
            // 
            // databox
            // 
            this.databox.Location = new System.Drawing.Point(90, 382);
            this.databox.Name = "databox";
            this.databox.Size = new System.Drawing.Size(288, 20);
            this.databox.TabIndex = 12;
            this.databox.Text = "test packet";
            // 
            // hostbox
            // 
            this.hostbox.Location = new System.Drawing.Point(12, 26);
            this.hostbox.Name = "hostbox";
            this.hostbox.Size = new System.Drawing.Size(283, 20);
            this.hostbox.TabIndex = 11;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(16, 385);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(68, 13);
            this.label2.TabIndex = 10;
            this.label2.Text = "Packet data:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(93, 13);
            this.label1.TabIndex = 9;
            this.label1.Text = "Enter host to ping:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(469, 414);
            this.Controls.Add(this.results);
            this.Controls.Add(this.closeit);
            this.Controls.Add(this.stopit);
            this.Controls.Add(this.sendit);
            this.Controls.Add(this.databox);
            this.Controls.Add(this.hostbox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Advance Ping";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox results;
        private System.Windows.Forms.Button closeit;
        private System.Windows.Forms.Button stopit;
        private System.Windows.Forms.Button sendit;
        private System.Windows.Forms.TextBox databox;
        private System.Windows.Forms.TextBox hostbox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
    }
}

